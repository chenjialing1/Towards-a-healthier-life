package com.example.myapplication.bean;

import io.realm.RealmObject;
import io.realm.annotations.PrimaryKey;

public class CanBean extends RealmObject {
    @PrimaryKey
    private int id;
    private String riqi;
    private String one;
    private String oneImg;
    private String two;
    private String twoImg;
    private String three;
    private String threeImg;
    private String four;
    private String fourImg;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getRiqi() {
        return riqi;
    }

    public void setRiqi(String riqi) {
        this.riqi = riqi;
    }

    public String getOne() {
        return one;
    }

    public void setOne(String one) {
        this.one = one;
    }

    public String getOneImg() {
        return oneImg;
    }

    public void setOneImg(String oneImg) {
        this.oneImg = oneImg;
    }

    public String getTwo() {
        return two;
    }

    public void setTwo(String two) {
        this.two = two;
    }

    public String getTwoImg() {
        return twoImg;
    }

    public void setTwoImg(String twoImg) {
        this.twoImg = twoImg;
    }

    public String getThree() {
        return three;
    }

    public void setThree(String three) {
        this.three = three;
    }

    public String getThreeImg() {
        return threeImg;
    }

    public void setThreeImg(String threeImg) {
        this.threeImg = threeImg;
    }

    public String getFour() {
        return four;
    }

    public void setFour(String four) {
        this.four = four;
    }

    public String getFourImg() {
        return fourImg;
    }

    public void setFourImg(String fourImg) {
        this.fourImg = fourImg;
    }
}
