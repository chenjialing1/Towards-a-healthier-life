package com.example.myapplication.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.TextView;

import com.blankj.utilcode.util.ToastUtils;
import com.bumptech.glide.Glide;
import com.example.myapplication.R;
import com.example.myapplication.bean.CanBean;
import com.example.myapplication.util.DbUtil;
import com.luck.picture.lib.PictureSelector;
import com.luck.picture.lib.config.PictureConfig;
import com.luck.picture.lib.config.PictureMimeType;
import com.luck.picture.lib.entity.LocalMedia;

import java.util.List;

public class MainActivity extends AppCompatActivity {
    public static String riqiStr;
    //1234
    public static int type;
    TextView tv_title;
    EditText et_miaoshu;
    ImageView iv_img,iv_img_show;
    public String imageStr = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        iv_img = (ImageView) findViewById(R.id.iv_img);
        iv_img_show =(ImageView)findViewById(R.id.iv_img_show);
        tv_title = (TextView) findViewById(R.id.tv_title);
        et_miaoshu = (EditText) findViewById(R.id.et_miaoshu);
        switch (type) {
            case 1: {
                tv_title.setText("BreakFast：");
            }
            break;
            case 2: {
                tv_title.setText("Lunch:");
            }
            break;
            case 3: {
                tv_title.setText("Dinner:");
            }
            break;
            case 4: {
                tv_title.setText("Snacks:");
            }
            break;
        }
    }

    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.iv_img: {
                PictureSelector.create(MainActivity.this)
                        .openGallery(PictureMimeType.ofImage())
                        .forResult(PictureConfig.CHOOSE_REQUEST);

            }
            break;
            case R.id.btn_jilu: {
                if (TextUtils.isEmpty(imageStr)) {
                    ToastUtils.showLong("请添加图片");
                }
                String miaoshu = et_miaoshu.getText().toString();
                List<CanBean> list = DbUtil.select(CanBean.class, "riqi", riqiStr);
                CanBean canBean = new CanBean();
                if (list != null && list.size() > 0) {
                    canBean = list.get(0);
                } else {
                    canBean.setId(DbUtil.getPk(CanBean.class));
                    canBean.setRiqi(riqiStr);
                }
                switch (type) {
                    case 1: {
                        canBean.setOne(miaoshu);
                        canBean.setOneImg(imageStr);
                    }
                    break;
                    case 2: {
                        canBean.setTwo(miaoshu);
                        canBean.setTwoImg(imageStr);
                    }
                    break;
                    case 3: {
                        canBean.setThree(miaoshu);
                        canBean.setThreeImg(imageStr);
                    }
                    break;
                    case 4: {
                        canBean.setFour(miaoshu);
                        canBean.setFourImg(imageStr);
                    }
                    break;
                }
                DbUtil.insertData(canBean);
                ToastUtils.showLong("上传成功");
            }
            break;
            case R.id.btn_quxiao: {
                finish();
            }
            break;
            default: {

            }
            break;
        }
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            switch (requestCode) {
                case PictureConfig.CHOOSE_REQUEST:
                    // 图片、视频、音频选择结果回调
                    List<LocalMedia> selectList = PictureSelector.obtainMultipleResult(data);
                    if (selectList != null && selectList.size() > 0) {
                        imageStr = selectList.get(0).getPath();
                        Glide.with(MainActivity.this).load(imageStr).into(iv_img_show);
                    }
                    // 例如 LocalMedia 里面返回三种path
                    // 1.media.getPath(); 为原图path
                    // 2.media.getCutPath();为裁剪后path，需判断media.isCut();是否为true  注意：音视频除外
                    // 3.media.getCompressPath();为压缩后path，需判断media.isCompressed();是否为true  注意：音视频除外
                    // 如果裁剪并压缩了，以取压缩路径为准，因为是先裁剪后压缩的
                    break;
            }
        }
    }

}