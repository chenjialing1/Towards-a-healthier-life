package com.example.myapplication.activity;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.ListView;
import android.widget.TextView;

import com.blankj.utilcode.util.ActivityUtils;
import com.blankj.utilcode.util.ToastUtils;
import com.codbking.calendar.CaledarAdapter;
import com.codbking.calendar.CalendarBean;
import com.codbking.calendar.CalendarDateView;
import com.codbking.calendar.CalendarUtil;
import com.codbking.calendar.CalendarView;
import com.example.myapplication.R;
import com.example.myapplication.bean.CanBean;
import com.example.myapplication.dialog.PromptDialog;
import com.example.myapplication.util.DbUtil;

import java.util.Date;
import java.util.List;

public class IndexActivity extends AppCompatActivity {
    com.codbking.calendar.CalendarDateView calendarDateView;
    TextView tv_yuefen;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_index);
        init();
    }

    private void init() {
        calendarDateView = (CalendarDateView) findViewById(R.id.calendarDateView);
        tv_yuefen = (TextView) findViewById(R.id.tv_yuefen);
        calendarDateView.setAdapter(new CaledarAdapter() {
            @Override
            public View getView(View convertView, ViewGroup parentView, CalendarBean bean) {
                //判断convertView为null，可以有效利用view的回收重用，左右滑动的效率高
                if (convertView == null) {
                    convertView = LayoutInflater.from(parentView.getContext()).inflate(R.layout.item_xiaomi, null);
                }

                TextView chinaText = (TextView) convertView.findViewById(R.id.chinaText);
                TextView text = (TextView) convertView.findViewById(R.id.text);

                text.setText("" + bean.day);
                //mothFlag 0是当月，-1是月前，1是月后
                if (bean.mothFlag != 0) {
//                    text.setTextColor(0xff9299a1);
                } else {
//                    text.setTextColor(0xff444444);
                }
                chinaText.setText(bean.chinaDay);

                return convertView;
            }
        });

        calendarDateView.setOnItemClickListener(new CalendarView.OnItemClickListener() {
            @Override
            public void onItemClick(View view, int postion, CalendarBean bean) {
                ToastUtils.showLong(bean.year + "/" + bean.moth + "/" + bean.day);
            }
        });
        calendarDateView.setOnItemClickListener(new CalendarView.OnItemClickListener() {
            @Override
            public void onItemClick(View view, int postion, CalendarBean bean) {
                tv_yuefen.setText(bean.year + "/" + bean.moth + "/" + bean.day);
                ToastUtils.showLong(bean.year + "/" + bean.moth + "/" + bean.day);
                check();
            }
        });
        int[] data = CalendarUtil.getYMD(new Date());
        tv_yuefen.setText(data[0] + "/" + data[1] + "/" + data[2]);
    }

    private void check() {
        List<CanBean> list = DbUtil.select(CanBean.class, "riqi", tv_yuefen.getText().toString());
        if (list != null && list.size() > 0) {
            PromptDialog promptDialog = new PromptDialog();
            promptDialog.setContent("There are records，Whether or not to see");
            promptDialog.setOnclick(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    SeeActivity.riqi = tv_yuefen.getText().toString();
                    ActivityUtils.startActivity(SeeActivity.class);
                    promptDialog.dismiss();
                }
            }, new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    promptDialog.dismiss();
                }
            });
            promptDialog.show(IndexActivity.this);
        }
    }

    public void onClick(View v) {
        MainActivity.riqiStr = tv_yuefen.getText().toString();
        switch (v.getId()) {
            case R.id.iv_zaocan: {
                MainActivity.type = 1;
            }
            break;
            case R.id.iv_wucan: {
                MainActivity.type = 2;
            }
            break;
            case R.id.iv_wancan: {
                MainActivity.type = 3;
            }
            break;
            case R.id.iv_jiacan: {
                MainActivity.type = 4;
            }
            break;
            default: {

            }
            break;
        }
        ActivityUtils.startActivity(MainActivity.class);
    }
}
