package com.example.myapplication.util;



import com.example.myapplication.App;

import java.util.ArrayList;
import java.util.List;

import io.realm.Realm;
import io.realm.RealmModel;
import io.realm.RealmObject;
import io.realm.RealmResults;

public class DbUtil {
    public static Realm mRealm;

    public static Realm getInstance() {
        if (mRealm == null) {
            synchronized (DbUtil.class) {
                if (mRealm == null) {
                    Realm.setDefaultConfiguration(App.instance.realmConfiguration);
                }
                mRealm = Realm.getDefaultInstance();
            }
        } else {
            mRealm = Realm.getDefaultInstance();
        }
        return mRealm;
    }

    public static <T extends RealmObject> void insertData(T modelList) {
        List<T> list = new ArrayList<>();
        list.add(modelList);
        insertData(list);
    }

    public static <T extends RealmObject> void insertData(List<T> modelList) {
        getInstance();
        mRealm.beginTransaction();
        mRealm.copyToRealmOrUpdate(modelList);
        mRealm.commitTransaction();
    }



    public static <T extends RealmObject> List<T> select(Class<T> tClass) {
        return getList(getInstance().where(tClass).findAll());
    }

    public static <T extends RealmObject> List<T> select(Class<T> tClass, String str, int value) {
        return getList(getInstance().where(tClass).equalTo(str, value).findAll());
    }

    public static <T extends RealmObject> List<T> select(Class<T> tClass, String str, Long value) {
        return getList(getInstance().where(tClass).equalTo(str, value).findAll());
    }

    public static <T extends RealmObject> List<T> select(Class<T> tClass, String str, int value, String str2, int value2) {
        return getList(getInstance().where(tClass).equalTo(str, value).equalTo(str2, value2).findAll());
    }

    public static <T extends RealmObject> List<T> select(Class<T> tClass, String str, String value) {
        return getList(getInstance().where(tClass).equalTo(str, value).findAll());
    }

    public static <T extends RealmObject> List<T> select(Class<T> tClass, String str, Boolean value) {
        return getList(getInstance().where(tClass).equalTo(str, value).findAll());
    }

    public static <T extends RealmObject> int getPk(Class<T> tClass) {
        return getInstance().where(tClass).findAll().size();
    }

    public static <T extends RealmObject> void delete(Class<T> tClass, String str, String value) {
        getInstance();
        mRealm.beginTransaction();
        mRealm.where(tClass).equalTo(str, value).findAll().deleteAllFromRealm();
        mRealm.commitTransaction();
    }

    public static <T extends RealmObject> void delete(Class<T> tClass) {
        try {
            getInstance();
            mRealm.beginTransaction();
            mRealm.where(tClass).findAll().deleteAllFromRealm();
            mRealm.commitTransaction();
        } catch (Exception e) {
        }

    }

    public static <E extends RealmModel> List<E> getList(RealmResults<E> data) {
        List<E> obtainList = new ArrayList<>();
        Realm realm = Realm.getDefaultInstance();
        if (data.size() == 0) {
            return obtainList;
        }
        for (int i = 0; i < data.size(); i++) {
            E temp = realm.copyFromRealm(data.get(i));
            obtainList.add(temp);
        }
        realm.close();
        return obtainList;
    }

}
