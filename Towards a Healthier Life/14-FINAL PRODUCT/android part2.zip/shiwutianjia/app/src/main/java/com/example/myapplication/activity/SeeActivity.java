package com.example.myapplication.activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.blankj.utilcode.util.ToastUtils;
import com.bumptech.glide.Glide;
import com.example.myapplication.R;
import com.example.myapplication.bean.CanBean;
import com.example.myapplication.util.DbUtil;

import java.util.List;

public class SeeActivity extends AppCompatActivity {
    public static String riqi;
    TextView tv_one, tv_two, tv_three, tv_four;
    ImageView iv_one, iv_two, iv_three, iv_four;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_see);
        tv_one = findViewById(R.id.tv_one);
        tv_two = findViewById(R.id.tv_two);
        tv_three = findViewById(R.id.tv_three);
        tv_four = findViewById(R.id.tv_four);
        iv_one = findViewById(R.id.iv_one);
        iv_two = findViewById(R.id.iv_two);
        iv_three = findViewById(R.id.iv_three);
        iv_four = findViewById(R.id.iv_four);
        initData();
    }

    private void initData() {
        List<CanBean> list = DbUtil.select(CanBean.class, "riqi", riqi);
        CanBean canBean = list.get(0);
        tv_one.setText(canBean.getOne());
        Glide.with(this).load(canBean.getOneImg()).into(iv_one);

        tv_two.setText(canBean.getTwo());
        Glide.with(this).load(canBean.getTwoImg()).into(iv_two);

        tv_three.setText(canBean.getThree());
        Glide.with(this).load(canBean.getThreeImg()).into(iv_three);

        tv_four.setText(canBean.getFour());
        Glide.with(this).load(canBean.getFourImg()).into(iv_four);
    }

    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_delete: {
                DbUtil.delete(CanBean.class, "riqi", riqi);
                ToastUtils.showLong("删除成功");
                finish();

            }
            break;
            default: {

            }
            break;
        }
    }
}
