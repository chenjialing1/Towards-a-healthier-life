package com.example.myapplication;

import android.app.Application;

import com.blankj.utilcode.util.Utils;

import io.realm.Realm;
import io.realm.RealmConfiguration;

public class App extends Application {
    public static App instance;
    public static RealmConfiguration realmConfiguration;

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        //初始化工具类
        Utils.init(this);
        //设置realm数据库
        Realm.init(this);
        realmConfiguration = new RealmConfiguration.Builder().name("apps").schemaVersion(0).build();
    }
}
